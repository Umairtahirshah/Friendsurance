This script was written using HPE-UFT 14.0
The script was written for Expense Tracker web application (http://thawing-shelf-73260.herokuapp.com)

How to execute the script.
1. Run HPE-UFT 14.0
2. Go to File > Open > Test , locate and open the file Expense Tracker.tsp
3. Before execution of script, 
	a. Manually Create a user in Expense Tracker and add the user/password in UserName & Password fields in global sheet
	b. Associate function libraries placed in folder <Expense Tracker\Libraries> with the script
4. Press Run button or F5 to execute the script


Note that following five test cases has been automated 
- To verify that URL launch successfully
- To verify that Login screen opens successfully
- To verify that user can login into the application successfully
- To verify that user can add new category successfully
- To verify that user can add expnese against added category
